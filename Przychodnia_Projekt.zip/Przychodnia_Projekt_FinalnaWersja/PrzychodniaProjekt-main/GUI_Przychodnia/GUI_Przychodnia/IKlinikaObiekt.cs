namespace SystemObslugiPrzychodni;

public interface IKlinikaObiekt
{
    string PobierzTypObiektu();
}