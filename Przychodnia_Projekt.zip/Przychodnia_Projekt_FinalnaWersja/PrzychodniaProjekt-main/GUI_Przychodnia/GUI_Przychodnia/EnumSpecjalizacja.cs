namespace SystemObslugiPrzychodni;

public enum EnumSpecjalizacja
{
    Internista,
    Kardiolog,
    Pediatra,
    Dermatolog,
    Okulista
}