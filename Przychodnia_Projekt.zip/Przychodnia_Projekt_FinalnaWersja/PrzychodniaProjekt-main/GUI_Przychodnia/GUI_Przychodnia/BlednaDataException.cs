namespace SystemObslugiPrzychodni;

public class BlednaDataException : Exception
{
    public BlednaDataException(string message) : base(message) { }
}